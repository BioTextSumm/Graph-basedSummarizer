'''
This code was written by Maedeh Dashti and Milad Moradi
'''

import sys, getopt
import nltk
import json
import json_lines
import random
import math
from numpy import double

#-------------------- CLASSES

class Feature:
    
    def __init__(self, word):
        self.token = word
        self.weight_list = []

class Sentence:
    
    def __init__(self, num, txt):
        self.sentence_number = num
        self.sentence_text = txt
        self.last_rank = 0.0
        self.rank = 0.0
        self.feature_list = []
        self.representation = []
        
        self.neighbor_list = []
        
    
    def cosine_similarity(self, second_vector):
        numerator = 0
        term1 = 0
        term2 = 0
        i = 0
        for weight in self.representation:
            numerator += weight * second_vector[i]
            term1 += weight ** 2
            term2 += second_vector[i] ** 2
            i += 1
            
        denominator = math.sqrt(term1) * math.sqrt(term2)
        cosine_sim = numerator / denominator
        return cosine_sim
    
    
    def set_token_list(self, tkn_list):
        self.feature_list = tkn_list
    
    def get_token_list(self):
        return self.feature_list;
    

class Similarity:
    
    def __init__(self, first, second, sim):
        self.first_sentence = first
        self.second_sentence = second
        self.value = sim


class Neighbor:
    
    def __init__(self, index, wght):
        self.node = index
        self.weight = wght
        

class Edge:
    
    def __init__(self, first, second, wght):
        self.first_node = first
        self.second_node = second
        self.weight = wght
        

#-------------------- THE MAIN SUMMARIZATION FUNCTION

def produce_summary(compression_rate, sentence_list, output_address):
    
    summary_size = math.ceil(len(sentence_list) * compression_rate) + 1
    print('\nSummary size: ', summary_size)

    
    #---------- Sort the sentences based on their rank
    for i in range(0, len(sentence_list)):
        for j in range(i+1, len(sentence_list)):
            if sentence_list[i].rank < sentence_list[j].rank:
                temp_sentence = sentence_list[i]
                sentence_list[i] = sentence_list[j]
                sentence_list[j] = temp_sentence
                
    
    #---------- Select the top sentences
    selected_sentences = []
    for i in range(0, summary_size):
        selected_sentences.append(sentence_list[i])
        
    
    #---------- Sort the sentences based on their order of appearance in the original document
    for i in range(0, len(selected_sentences)):
        for j in range(i+1, len(selected_sentences)):
            if selected_sentences[i].sentence_number > selected_sentences[j].sentence_number:
                temp_sentence = selected_sentences[i]
                selected_sentences[i] = selected_sentences[j]
                selected_sentences[j] = temp_sentence
    
    
    print('---------- Sorted selected sentences --------')
    for i in range(0, len(selected_sentences)):
        print(selected_sentences[i].sentence_number)


    #----------------------- Produce the final summary
    final_summary = ''
    for i in range(0, len(selected_sentences)):
        print(selected_sentences[i].sentence_text)
        if i > 0:
            final_summary += ' '
        final_summary += selected_sentences[i].sentence_text
        

    '''
    final_output = '<html>'
    final_output += '\n<head>'
    final_output += '\n</head>'
    final_output += '\n<body bgcolor="white">'
    final_output += '\n<a name="1">[1]</a> <a href="#1" id=1>'
    final_output += final_summary
    final_output += '\n</a>'
    final_output += '\n</body>'
    final_output += '\n</html>'
    '''

    output_file_text = open(output_address, 'w')
    output_file_text.write(final_summary)
    output_file_text.close()
    
    return

#-------------------- MAIN BODY OF SUMMARIZER

def main(argv):
    
    input_file = ''
    output_file = ''
    compression_rate = 0.3
    top_k = 0.7
    ranking_alg = 'pr'
    
    try:
        opts, args = getopt.getopt(argv, "hi:o:c:k:r:", ["inputfile=", "outputfile=", "compression_rate=", "top_k_similarity=", "ranking_algorithm"])
        
    except getopt.GetoptError:
        print("Summarizer.py -i <InputFile> -o <OutputFile> -c <CompressionRate> -k <TopKsimilarity> -r <RankingAlgorithm>")
        sys.exit(2)
        
    for opt, arg in opts:
        if opt == '-h':
            print("Summarizer.py -i <InputFile> -o <OutputFile> -c <CompressionRate> -k <TopKsimilarity> -r <RankingAlgorithm>")
            sys.exit()
        elif opt in ("-i", "--inputfile"):
            input_file = arg
        elif opt in ("-o", "--outputfile"):
            output_file = arg
        elif opt in ("-c", "--compression_rate"):
            compression_rate = double(arg)
        elif opt in ("-k", "--top_k_similarity"):
            top_k = double(arg)
        elif opt in ("-r", "--ranking_algorithm"):
            ranking_alg = arg
            
    print("Input file is:", input_file)
    print("Output file is:", output_file)
    print("Compression rate is:", compression_rate)
    print("Top K similarity is:", top_k)
    print("Ranking algorithm is:", ranking_alg)
    
    
    #-------------------- Preprocessing --------------------
    
    input_address = 'INPUT\\' + input_file
    
    print('---------- Preprocessing started ----------\n')
    
    opened_file = open(input_address, encoding = "utf8")
    print("-----File opened-----")
    
    input_text = opened_file.read()
    print("-----File read-----")
    
    input_sentences = nltk.sent_tokenize(input_text)
    
    sentence_split_text = ''
    preprocessed_text = ''
    sentence_num = 1
    
    for sentence in input_sentences:
        tokenized_sentence = nltk.word_tokenize(sentence)
        
        if sentence_num > 1:
            sentence_split_text += '\n'
            preprocessed_text += '\n'
        
        sentence_split_text += sentence
        preprocessed_text += str(tokenized_sentence)
        sentence_num += 1
        
    temp_file_address = 'TEMP\\temp_input.txt'
    temp_file_token_address = 'TEMP\\temp_input_token.txt'
    temp_file = open(temp_file_address, 'w')
    temp_file_token = open(temp_file_token_address, 'w')
    temp_file.write(sentence_split_text)
    temp_file_token.write(preprocessed_text)
    temp_file.close()
    temp_file_token.close()
    
    #-------------------- Feature extraction --------------------
    
    import subprocess
    feature_eaxtraction_script = "python BERT/extract_features.py --input_file=TEMP/temp_input.txt --output_file=TEMP/temp_features.jsonl --vocab_file=BERT/vocab.txt --bert_config_file=BERT/bert_config.json --init_checkpoint=BERT/bert_model.ckpt --layers=-1 --max_seq_length=128 --batch_size=8"
    subprocess.call(feature_eaxtraction_script, shell=True)
    #exec(open("extract_features.py --input_file=Input.txt --output_file=Example100.jsonl --vocab_file=vocab.txt --bert_config_file=bert_config.json --init_checkpoint=bert_model.ckpt --layers=-1 --max_seq_length=128 --batch_size=8").read())
    
    
    #-------------------- Sentence representation --------------------
    
    print('---------- Text summarizer started ----------\n')
    
    input_address_text = 'TEMP\\temp_input.txt'
    input_address_feature = 'TEMP\\temp_features.jsonl'
    output_address = 'OUTPUT\\' + output_file


    input_file = open(input_address_text)
    print("-----File opened-----")

    input_text = input_file.read()
    print("-----File read-----")

    input_sentences = nltk.sent_tokenize(input_text)

    sentence_list = []
    sentence_num = 0

    for sentence in input_sentences:
        sentence_num += 1
        temp_sentence = Sentence(sentence_num, sentence)
        sentence_list.append(temp_sentence)

    #--------------------

    sentence_num = 0
    with open(input_address_feature) as input_file:
        for line in json_lines.reader(input_file):
            feature_set = line['features']
        
            for feature in feature_set:
                if feature['token'] in ['[CLS]', '[SEP]']:
                    continue;
            
                temp_feature = Feature(feature['token'])
            
                for layer in feature['layers']:
                    temp_feature.weight_list = layer['values']
                    
                if sentence_num < len(sentence_list):
                    sentence_list[sentence_num].feature_list.append(temp_feature)
                            
            sentence_num += 1
        
    print('-----------------------------------------------')

    #-------------------- Compute a representation for every sentence

    for sentence in sentence_list:
        for weight in sentence.feature_list[0].weight_list:
            sentence.representation.append(0.0)
        
        for feature in sentence.feature_list:
            i = 0
            for weight in feature.weight_list:
                sentence.representation[i] += weight
                i += 1
            
        j = 0
        for weight in sentence.representation:
            sentence.representation[j] /= len(sentence.feature_list)
            j += 1


        
        
    #-------------------- Ranking algorithm
    print('\n---------- Ranking started ----------')

    #----- Compute cosine similarity between every pair of sentences
    
    similarity_list = []
    
    for i in range(0, len(sentence_list)):
        for j in range(i+1, len(sentence_list)):
            sentence_1 = i
            sentence_2 = j
            temp_sim_value = sentence_list[i].cosine_similarity(sentence_list[j].representation)
            temp_similarity = Similarity(sentence_1, sentence_2, temp_sim_value)
            similarity_list.append(temp_similarity)
            
    
    #----- Sort the similarity list
    
    for i in range(0, len(similarity_list)):
        for j in range(i+1, len(similarity_list)):
            if similarity_list[i].value < similarity_list[j].value:
                temp_similarity = similarity_list[i]
                similarity_list[i] = similarity_list[j]
                similarity_list[j] = temp_similarity
                
    #--- Select the top K similarity values and make a list of edges
    
    top_k_size = math.ceil(len(similarity_list) * top_k) + 1
    
    edge_list = []
    
    for i in range(0, top_k_size):
        temp_edge = Edge(similarity_list[i].first_sentence, similarity_list[i].second_sentence, similarity_list[i].value)
        edge_list.append(temp_edge)
        
    
    #----- Make a neighbor list for every node
    
    for i in range(0, len(sentence_list)):
        
        for j in range(0, len(edge_list)):
            if edge_list[j].first_node == i:
                temp_neighbor = Neighbor(edge_list[j].second_node, edge_list[j].weight)
                sentence_list[i].neighbor_list.append(temp_neighbor)
            elif edge_list[j].second_node == i:
                temp_neighbor = Neighbor(edge_list[j].first_node, edge_list[j].weight)
                sentence_list[i].neighbor_list.append(temp_neighbor) 
    
    
    #------------------------------ Starting ranking algorithm
    
    #----- Initialize the ranks
    
    for i in range(0, len(sentence_list)):
        sentence_list[i].rank = 1.0
        sentence_list[i].last_rank = 1.0
    
    convergence_threshold = 0.0001
    
    
    #---------- PageRank
    if ranking_alg == 'pr':
        
        print('---------- Ranking algorithm: PageRank ----------')
        
        damping_factor = 0.5
        convergence = False
        
        iteration = 1
        while(convergence != True):
            
            print('---------- Iteration: ', iteration)
            
            for i in range(0, len(sentence_list)):
                sentence_list[i].last_rank = sentence_list[i].rank
                
                weighted_sum_strength = 0
                
                for j in range(0, len(sentence_list[i].neighbor_list)):
                    neighbor_index = sentence_list[i].neighbor_list[j].node
                    edge_weight = sentence_list[i].neighbor_list[j].weight
                    neighbor_strength = 0
                    
                    for k in range(0, len(sentence_list[neighbor_index].neighbor_list)):
                        neighbor_strength += sentence_list[neighbor_index].neighbor_list[k].weight
                        
                    weighted_sum_strength += edge_weight * (sentence_list[neighbor_index].rank / neighbor_strength)
                    
                sentence_list[i].rank = (1 - damping_factor) + (damping_factor * weighted_sum_strength)
                
            #----- Check for convergence condition
            convergence = True
            for i in range(0, len(sentence_list)):
                if abs(sentence_list[i].last_rank - sentence_list[i].rank) > convergence_threshold:
                    convergence = False
                       
            iteration += 1
            
            
    #---------- HITS
    if ranking_alg == 'hits':
        
        print('---------- Ranking algorithm: HITS ----------')
        
        convergence = False
        
        iteration = 1
        while(convergence != True):
            
            print('---------- Iteration: ', iteration)
            
            for i in range(0, len(sentence_list)):
                sentence_list[i].last_rank = sentence_list[i].rank
                
                sentence_list[i].rank = 0
                for j in range(0, len(sentence_list[i].neighbor_list)):
                    neighbor_index = sentence_list[i].neighbor_list[j].node
                    edge_weight = sentence_list[i].neighbor_list[j].weight
                    
                    sentence_list[i].rank += edge_weight * sentence_list[neighbor_index].rank
                    
            #----- Check for convergence condition
            convergence = True
            for i in range(0, len(sentence_list)):
                if abs(sentence_list[i].last_rank - sentence_list[i].rank) > convergence_threshold:
                    convergence = False
                    
            iteration += 1
            
            
    #---------- PPF
    if ranking_alg == 'ppf':
        
        print('---------- Ranking algorithm: PPF ----------')
        
        convergence = False
        
        nodes_size = len(sentence_list)
        
        iteration = 1
        while(convergence != True):
            
            print('---------- Iteration: ', iteration)
            
            for i in range(0, len(sentence_list)):
                sentence_list[i].last_rank = sentence_list[i].rank
                
                sentence_list[i].rank = 0
                for j in range(0, len(sentence_list[i].neighbor_list)):
                    neighbor_index = sentence_list[i].neighbor_list[j].node
                    edge_weight = sentence_list[i].neighbor_list[j].weight
                    
                    sentence_list[i].rank += 1 + (edge_weight * sentence_list[neighbor_index].rank)
                    
                sentence_list[i].rank = (1 / nodes_size) * sentence_list[i].rank
                    
            #----- Check for convergence condition
            convergence = True
            for i in range(0, len(sentence_list)):
                if abs(sentence_list[i].last_rank - sentence_list[i].rank) > convergence_threshold:
                    convergence = False
                    
            iteration += 1
                
                    
    #----- End of ranking algorithm
    
    
    #---------- Call the function that produces the summary
    if ranking_alg in ('pr', 'hits', 'ppf'):
        output_address = 'OUTPUT\\' + output_file
        produce_summary(compression_rate, sentence_list, output_address)
    else:
        print('Error: The ranking algorithm must be specified from pr, hits, or ppf')
    
    
    
    print("\n")
    print("---------- Finished ----------")



if __name__ == '__main__':
    main(sys.argv[1:])